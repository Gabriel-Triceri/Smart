package com.smartmeeting;

import com.smartmeeting.api.SmartmeetingApiApplication;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = SmartmeetingApiApplication.class)
class ContextLoadTest {

    @Test
    void contextLoads() {
    }
}
