package com.smartmeeting.enums;

public enum ProjectStatus {
    PLANNING,
    ACTIVE,
    PAUSED,
    COMPLETED,
    ARCHIVED
}
