// MovimentacaoTarefaRequest.java (SUGESTÃO DE CORREÇÃO NO BACKEND)
package com.smartmeeting.dto;

import jakarta.validation.constraints.NotNull;

public class MovimentacaoTarefaRequest {
    @NotNull
    // Mude de StatusTarefa para Long, que é o ID da Coluna do Kanban
    private Long colunaId;
    private Integer newPosition;

    public Long getColunaId() { // Getter também deve mudar
        return colunaId;
    }

    public void setColunaId(Long colunaId) { // Setter também deve mudar
        this.colunaId = colunaId;
    }

    public Integer getNewPosition() {
        return newPosition;
    }

    public void setNewPosition(Integer newPosition) {
        this.newPosition = newPosition;
    }
}