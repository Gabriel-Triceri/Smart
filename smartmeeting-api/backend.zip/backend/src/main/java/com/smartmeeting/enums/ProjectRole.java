package com.smartmeeting.enums;

public enum ProjectRole {
    OWNER,
    ADMIN,
    MEMBER_EDITOR
}
