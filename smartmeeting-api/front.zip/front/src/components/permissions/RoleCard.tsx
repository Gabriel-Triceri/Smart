import React from 'react';
import { Shield, Edit2, Settings } from 'lucide-react';
import { Role } from '../../types/permissions';

interface RoleCardProps {
    role: Role;
    onEdit: (id: number, nome: string) => void;
    onManagePermissions: (id: number) => void;
}

export const RoleCard: React.FC<RoleCardProps> = ({ role, onEdit, onManagePermissions }) => {
    return (
        <div className="bg-white dark:bg-mono-800 rounded-lg border border-mono-200 dark:border-mono-700 p-4 hover:shadow-md transition-shadow">
            {/* Header */}
            <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-accent-100 dark:bg-accent-900/30 rounded-lg">
                        <Shield className="w-5 h-5 text-accent-600 dark:text-accent-400" />
                    </div>
                    <div>
                        <h3 className="font-semibold text-mono-900 dark:text-mono-100">
                            {role.nome}
                        </h3>
                        <p className="text-xs text-mono-500 dark:text-mono-400">
                            {role.permissions.length} {role.permissions.length === 1 ? 'permissão' : 'permissões'}
                        </p>
                    </div>
                </div>
            </div>

            {/* Permissions */}
            {role.permissions.length > 0 && (
                <div className="mb-3">
                    <div className="flex flex-wrap gap-1">
                        {role.permissions.slice(0, 3).map((permission, index) => (
                            <span
                                key={index}
                                className="inline-flex items-center px-2 py-1 text-xs font-medium bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded"
                            >
                                {permission}
                            </span>
                        ))}
                        {role.permissions.length > 3 && (
                            <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-mono-100 dark:bg-mono-700 text-mono-600 dark:text-mono-400 rounded">
                                +{role.permissions.length - 3}
                            </span>
                        )}
                    </div>
                </div>
            )}

            {/* Actions */}
            <div className="flex items-center gap-2 pt-3 border-t border-mono-200 dark:border-mono-700">
                <button
                    onClick={() => onEdit(role.id, role.nome)}
                    className="flex-1 flex items-center justify-center gap-2 px-3 py-2 text-sm font-medium text-mono-700 dark:text-mono-300 bg-mono-100 dark:bg-mono-700 hover:bg-mono-200 dark:hover:bg-mono-600 rounded-lg transition-colors"
                >
                    <Edit2 className="w-4 h-4" />
                    Editar
                </button>
                <button
                    onClick={() => onManagePermissions(role.id)}
                    className="flex-1 flex items-center justify-center gap-2 px-3 py-2 text-sm font-medium text-accent-600 dark:text-accent-400 bg-accent-50 dark:bg-accent-900/20 hover:bg-accent-100 dark:hover:bg-accent-900/30 rounded-lg transition-colors"
                >
                    <Settings className="w-4 h-4" />
                    Permissões
                </button>
            </div>
        </div>
    );
};
