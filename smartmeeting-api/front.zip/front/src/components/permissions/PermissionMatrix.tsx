import React from 'react';
import { Check } from 'lucide-react';
import { useRoles } from '../../hooks/useRoles';
import { usePermissions } from '../../hooks/usePermissions';
import LoadingSkeleton from '../common/LoadingSkeleton';

export const PermissionMatrix: React.FC = () => {
    const { roles, isLoading: rolesLoading, addPermissionToRole, removePermissionFromRole } = useRoles();
    const { permissions, isLoading: permissionsLoading } = usePermissions();

    const isLoading = rolesLoading || permissionsLoading;

    const hasPermission = (rolePermissions: string[], permissionName: string) => {
        return rolePermissions.includes(permissionName);
    };

    const handleToggle = async (roleId: number, permissionName: string, currentlyHas: boolean) => {
        const permission = permissions.find(p => p.nome === permissionName);
        if (!permission) return;

        if (currentlyHas) {
            await removePermissionFromRole(roleId, permission.id);
        } else {
            await addPermissionToRole(roleId, permission.id);
        }
    };

    if (isLoading) {
        return <LoadingSkeleton />;
    }

    if (roles.length === 0 || permissions.length === 0) {
        return (
            <div className="text-center py-12">
                <h3 className="text-lg font-semibold text-mono-900 dark:text-mono-100 mb-2">
                    Dados Insuficientes
                </h3>
                <p className="text-mono-600 dark:text-mono-400">
                    Crie roles e permissões para visualizar a matriz
                </p>
            </div>
        );
    }

    return (
        <div className="bg-white dark:bg-mono-800 rounded-lg border border-mono-200 dark:border-mono-700 overflow-hidden">
            <div className="p-4 border-b border-mono-200 dark:border-mono-700">
                <h3 className="text-lg font-semibold text-mono-900 dark:text-mono-100">
                    Matriz de Permissões
                </h3>
                <p className="text-sm text-mono-600 dark:text-mono-400">
                    Visualize e gerencie permissões de todas as roles
                </p>
            </div>

            <div className="overflow-x-auto">
                <table className="w-full">
                    <thead className="bg-mono-50 dark:bg-mono-700/50">
                        <tr>
                            <th className="sticky left-0 z-10 bg-mono-50 dark:bg-mono-700/50 px-4 py-3 text-left text-sm font-semibold text-mono-900 dark:text-mono-100">
                                Role
                            </th>
                            {permissions.map(permission => (
                                <th
                                    key={permission.id}
                                    className="px-4 py-3 text-center text-xs font-medium text-mono-700 dark:text-mono-300 min-w-[120px]"
                                >
                                    <div className="transform -rotate-45 origin-left">
                                        {permission.nome}
                                    </div>
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-mono-200 dark:divide-mono-700">
                        {roles.map(role => (
                            <tr key={role.id} className="hover:bg-mono-50 dark:hover:bg-mono-700/30">
                                <td className="sticky left-0 z-10 bg-white dark:bg-mono-800 px-4 py-3 font-medium text-mono-900 dark:text-mono-100">
                                    {role.nome}
                                </td>
                                {permissions.map(permission => {
                                    const has = hasPermission(role.permissions, permission.nome);
                                    return (
                                        <td key={permission.id} className="px-4 py-3 text-center">
                                            <button
                                                onClick={() => handleToggle(role.id, permission.nome, has)}
                                                className={`inline-flex items-center justify-center w-6 h-6 rounded ${has
                                                        ? 'bg-accent-500 dark:bg-accent-600 hover:bg-accent-600 dark:hover:bg-accent-700'
                                                        : 'border-2 border-mono-300 dark:border-mono-500 hover:border-accent-400 dark:hover:border-accent-500'
                                                    } transition-colors`}
                                            >
                                                {has && <Check className="w-4 h-4 text-white" />}
                                            </button>
                                        </td>
                                    );
                                })}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
